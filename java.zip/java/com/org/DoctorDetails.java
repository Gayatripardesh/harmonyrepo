package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DoctorDetails")
public class DoctorDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DoctorDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement" ,"root","root");
			  PreparedStatement ps = con.prepareStatement("select d_name , d_ post , d_email from doctor where d_name='Chetan_Dhote'");
			  ResultSet rs = ps.executeQuery();
			  
			  while(rs.next()) {
				  
				  RequestDispatcher rd = request.getRequestDispatcher("mydoctor.jsp");
				  rd.include(request, response);
				  HttpSession session = request.getSession();
				  session.setAttribute("ses_name", rs.getString("d_name"));
				  session.setAttribute("ses_post", rs.getString("d_post"));
				  session.setAttribute("ses_email", rs.getString("d_email"));
				 
			  }
		  }catch(Exception e) {
			  e.printStackTrace();
			  out.print("invalid Data");
		  }	
	}

}
