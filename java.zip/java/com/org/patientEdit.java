package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/patientEdit")
public class patientEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public patientEdit() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String name = request.getParameter("inputName");
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		String email = request.getParameter("inputEmail");
		
		
		PrintWriter out=response.getWriter();
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement?useSSL=false", "root", "root");
			PreparedStatement ps= conn.prepareStatement("UPDATE patient SET p_name=?,p_username=?,p_password=?,p_email=?, where username=?");
			ps.setString(2, name);
			ps.setString(3, username);
			ps.setString(4, password);
			ps.setString(5, email);
			
		
			ps.executeUpdate();
			response.sendRedirect("viewallpatientsTable.jsp");
//			out.print("updated");
			
		}
		catch(Exception e) {
			out.print("not updated");
		}
		
	}

}