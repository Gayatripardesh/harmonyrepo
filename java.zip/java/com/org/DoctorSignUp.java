package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DoctorSignUp")
public class DoctorSignUp extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("inputName");
		String post=request.getParameter("inputPost");
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String email=request.getParameter("inputEmail");
		
		PrintWriter out=response.getWriter();
		
		try {
			//Register the driver class
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection 
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement" ,"root","root");
			
			//Create Statement
			Statement stat=con.createStatement();
			
			//Execute Query
			stat.executeUpdate("insert into doctor(d_name,d_post,d_username,d_password,d_email) values ('"+name+"','"+post+"','"+username+"','"+password+"','"+email+"')");
			
			out.println("Data inserted successfully!!");
			
			//Close Connection
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
