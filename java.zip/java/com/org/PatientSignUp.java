package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PatientSignUp")
public class PatientSignUp extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String name=request.getParameter("inputName");
	String username=request.getParameter("user");
	String password=request.getParameter("pass");
	String email=request.getParameter("inputEmail");
	
	PrintWriter out=response.getWriter();
	
	try {
		//Register the Driver Class
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//Establish Connection
		Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement","root","root");
		
		//Create Statement
		Statement stat=con.createStatement();
		
		//Execute Query
		stat.executeUpdate("insert into patient(p_name,p_username,p_password,p_email) values('"+name+"','"+username+"','"+password+"','"+email+"')");
		
		out.println("Patient's Data Inserted Successfully!!");
		
		//CLose Connection 
		con.close();
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
		
		
	}

}
