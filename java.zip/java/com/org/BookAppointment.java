package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookAppointment")
public class BookAppointment extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fullname=request.getParameter("inputName");
		String email=request.getParameter("inputEmail");
		String phoneno=request.getParameter("inputPhoneno");
		String selectdoc=request.getParameter("inputSelectDoc");
		String appointdate=request.getParameter("inputAppointDate");
		String appointtime=request.getParameter("inputAppTime");
		
		PrintWriter out=response.getWriter();
		
		try {
			//Register the Driver Class
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection 
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement","root","root");
			
			//Create Statement
			Statement stat=con.createStatement();
			
			//Execute Query
			stat.executeUpdate("insert into bookappointment(fullname,email,phoneno,selectdoctor,appointdate,appointtime) values('"+fullname+"','"+email+"','"+phoneno+"','"+selectdoc+"','"+appointdate+"','"+appointtime+"')");
			out.print("Appointment Booked Successfully!!");
			
			//Close Connection
			con.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
			out.println("Invaid ,Appointment not book");
		}
		
	}

}
