package com.org;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditDoctor")
public class EditDoctor extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
    	String name=request.getParameter("inputName");
		String post=request.getParameter("inputPost");
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String email=request.getParameter("inputEmail");
		
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		PrintWriter out=response.getWriter();
		
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalmanagement","root","root");
			ps=con.prepareStatement("update from doctor set d_name=? , d_post=? , d_username=? , d_password=? , d_email=? where d_id=?");
			
			ps.setString(1, name);
			ps.setString(2, post);
			ps.setString(3, username);
			ps.setString(4, password);
			ps.setString(5, email);
			
			ps.executeUpdate();
			response.sendRedirect("viewalldoctorsTable.jsp");
			out.println("updated!!");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			response.sendRedirect("errorEditdoctor.jsp");
		}
		
    }
  }

