package com.org;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Admin")
public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Admin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		String user=request.getParameter("input1");
		String pass=request.getParameter("input2");
		
		String user1="Gayatri";
		String pass1="gayatri123";
		
		if(user.equals(user1) && pass.equals(pass1)) {
			response.sendRedirect("adminprofile.jsp");
		}
		else {
			out.println("The username or password is Invaild,Please Check again");
		}
	}

}
